[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string] $GameRoot
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'
if ($PSVersionTable.PSEdition -ne 'Desktop') { throw 'Run this pinned build with Windows PowerShell 5.1.' }

$runtimeRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectRoot = Split-Path -Parent (Split-Path -Parent $runtimeRoot)
$sourceRoot = Join-Path $runtimeRoot 'main'
$outputRoot = Join-Path $projectRoot 'out'
$stageRoot = Join-Path $projectRoot 'tmp'
$dotnetPath = 'C:\Program Files\dotnet\dotnet.exe'
$compilerPath = 'C:\Program Files\dotnet\sdk\10.0.401\Roslyn\bincore\csc.dll'
$expectedDotnetSha256 = '21A46F1E5235CF4E844B9DE5429F0E198B9C97A41F0503A66442F1D639CA3EE6'
$expectedCompilerSha256 = '89C788F615634094CC441593D167D9FBA9A9F049A5D1DDEA87D4FDE222D6F42C'
$expectedAssemblyCSharpMvid = [guid]'7c57b7de-39a1-497d-bf48-8d5d1d4a1ff1'
$expectedAssemblyCSharpSha256 = 'AA4275991736D276EC75BB4047E45F76E0242AA47D9895890F3761098D4CC146'
$expectedHarmonySha256 = 'C349E1A3FD13FA5A9FACC9805A5E160161B14489F46F6BDD38202B8E124F78DF'
$expectedHarmonyMvid = [guid]'7b787fec-e12a-47a6-8027-108671090713'

function Get-CanonicalPath {
    param([string] $Path)
    return [System.IO.Path]::GetFullPath($Path).TrimEnd([System.IO.Path]::DirectorySeparatorChar, [System.IO.Path]::AltDirectorySeparatorChar)
}

function Test-ContainedPath {
    param([string] $Parent, [string] $Child)
    $prefix = (Get-CanonicalPath $Parent) + [System.IO.Path]::DirectorySeparatorChar
    return (Get-CanonicalPath $Child).StartsWith($prefix, [System.StringComparison]::OrdinalIgnoreCase)
}

function Get-Sha256 {
    param([string] $Path)
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
}

$project = Get-CanonicalPath $projectRoot
$game = Get-CanonicalPath $GameRoot
$output = Get-CanonicalPath $outputRoot
$stage = Get-CanonicalPath $stageRoot
if (-not (Test-ContainedPath -Parent $project -Child $output) -or -not (Test-ContainedPath -Parent $project -Child $stage)) { throw 'Build roots escaped the project.' }
if (-not (Test-Path -LiteralPath (Join-Path $game '7DaysToDie.exe') -PathType Leaf)) { throw 'Game root is not recognized.' }
if (-not (Test-Path -LiteralPath $dotnetPath -PathType Leaf) -or -not (Test-Path -LiteralPath $compilerPath -PathType Leaf)) { throw 'Pinned compiler is missing.' }
if ((Get-Sha256 $dotnetPath) -cne $expectedDotnetSha256) { throw 'Pinned dotnet host hash changed.' }
if ((Get-Sha256 $compilerPath) -cne $expectedCompilerSha256) { throw 'Pinned compiler hash changed.' }
if (@(Get-Process -Name '7DaysToDie', '7DaysToDieServer', '7DaysToDie_EAC' -ErrorAction SilentlyContinue).Count -gt 0) { throw 'Game process is running; build stopped.' }

$managed = Join-Path $game '7DaysToDie_Data\Managed'
$tfpHarmony = Join-Path $game 'Mods\0_TFP_Harmony\0Harmony.dll'
$references = @(
    'mscorlib.dll',
    'netstandard.dll',
    'System.dll',
    'System.Core.dll',
    'Assembly-CSharp.dll',
    'UnityEngine.CoreModule.dll',
    'LogLibrary.dll'
) | ForEach-Object { Join-Path $managed $_ }
$references = @($references) + @($tfpHarmony)
foreach ($reference in $references) { if (-not (Test-Path -LiteralPath $reference -PathType Leaf)) { throw "Pinned reference missing: $([System.IO.Path]::GetFileName($reference))" } }
if ((Get-Sha256 $tfpHarmony) -cne $expectedHarmonySha256) { throw 'TFP Harmony hash changed.' }

$assemblyCSharp = [System.Reflection.Assembly]::ReflectionOnlyLoadFrom((Join-Path $managed 'Assembly-CSharp.dll'))
if ($assemblyCSharp.ManifestModule.ModuleVersionId -ne $expectedAssemblyCSharpMvid) { throw 'Assembly-CSharp MVID changed.' }
if ((Get-Sha256 (Join-Path $managed 'Assembly-CSharp.dll')) -cne $expectedAssemblyCSharpSha256) { throw 'Assembly-CSharp hash changed.' }
$harmonyAssembly = [System.Reflection.Assembly]::ReflectionOnlyLoadFrom($tfpHarmony)
if ($harmonyAssembly.ManifestModule.ModuleVersionId -ne $expectedHarmonyMvid) { throw 'TFP Harmony MVID changed.' }

$sourceNames = @(
    'c0140.cs',
    'c0147.cs',
    'c0167.cs',
    'c0181.cs',
    'c0184.cs',
    'c0185.cs',
    'PolicyV1.cs',
    'PolicyV2.cs',
    'BiomePreference.cs',
    'ResultV1.cs',
    'c0213.cs',
    'PlacedPoiResolver.cs',
    'PlacedTraderResolver.cs',
    'c0217.cs',
    'c0218.cs'
)
$sources = @($sourceNames | ForEach-Object { Join-Path $sourceRoot $_ })
foreach ($source in $sources) { if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Release source missing: $([System.IO.Path]::GetFileName($source))" } }

[void][System.IO.Directory]::CreateDirectory($output)
[void][System.IO.Directory]::CreateDirectory($stage)
$attempt = 'alpha-core-' + [guid]::NewGuid().ToString('N')
$attemptRoot = Join-Path $stage $attempt
$buildOne = Join-Path $attemptRoot 'build-1'
$buildTwo = Join-Path $attemptRoot 'build-2'
[void][System.IO.Directory]::CreateDirectory($buildOne)
[void][System.IO.Directory]::CreateDirectory($buildTwo)

function Invoke-PinnedBuild {
    param([string] $Destination)
    $arguments = New-Object System.Collections.Generic.List[string]
    foreach ($value in @('/nologo','/noconfig','/nostdlib+','/target:library','/platform:anycpu','/langversion:7.3','/optimize+','/checked+','/warn:4','/warnaserror+','/deterministic+','/debug-')) { [void]$arguments.Add($value) }
    [void]$arguments.Add('/out:' + $Destination)
    foreach ($reference in $references) { [void]$arguments.Add('/reference:' + $reference) }
    foreach ($source in $sources) { [void]$arguments.Add($source) }
    & $dotnetPath $compilerPath @arguments
    if ($LASTEXITCODE -ne 0 -or -not [System.IO.File]::Exists($Destination)) { throw "Release build failed with exit code $LASTEXITCODE." }
}

$dllOne = Join-Path $buildOne 'd0163.dll'
$dllTwo = Join-Path $buildTwo 'd0163.dll'
Invoke-PinnedBuild -Destination $dllOne
Invoke-PinnedBuild -Destination $dllTwo
$hashOne = Get-Sha256 $dllOne
$hashTwo = Get-Sha256 $dllTwo
if ($hashOne -cne $hashTwo) { throw 'Deterministic double build mismatch.' }

$candidateRoot = Join-Path $output $attempt
$payloadRoot = Join-Path $candidateRoot 'mod'
$bridgeRoot = Join-Path $payloadRoot 'Bridge'
[void][System.IO.Directory]::CreateDirectory($bridgeRoot)
[System.IO.File]::Copy($dllOne, (Join-Path $payloadRoot 'd0163.dll'), $false)
[System.IO.File]::Copy((Join-Path $sourceRoot 'ModInfo.xml'), (Join-Path $payloadRoot 'ModInfo.xml'), $false)

$record = [pscustomobject][ordered]@{
    schema = 'hrs-release-build/v1'
    attempt = $attempt
    createdUtc = [datetime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ss.fffZ', [System.Globalization.CultureInfo]::InvariantCulture)
    sourceFiles = $sourceNames
    sourceHashes = @($sources | ForEach-Object { [pscustomobject]@{ path=[System.IO.Path]::GetFileName($_); sha256=Get-Sha256 $_ } })
    compiler = [pscustomobject]@{ dotnet=$dotnetPath; dotnetSha256=Get-Sha256 $dotnetPath; csc=$compilerPath; cscSha256=Get-Sha256 $compilerPath }
    references = @($references | ForEach-Object { [pscustomobject]@{ name=[System.IO.Path]::GetFileName($_); sha256=Get-Sha256 $_ } })
    assemblyCSharpMvid = $assemblyCSharp.ManifestModule.ModuleVersionId.ToString()
    dllBytes = (New-Object System.IO.FileInfo($dllOne)).Length
    dllSha256 = $hashOne
    deterministicDoubleBuild = $true
    candidateRoot = $candidateRoot
}
$recordPath = Join-Path $candidateRoot 'j0144.json'
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($recordPath, (ConvertTo-Json -InputObject $record -Depth 6), $utf8)
$record
