# Historical Random Start 1.2.3

Keep this entire folder together.

## Start

1. Run START.bat.
2. Select your 7 Days to Die installation if prompted.
3. Enter the exact name you will use for the new game.
4. Choose Standard or Random.
5. For Random, optionally enable:
   Protect from hazards in starting biome
6. Click Apply Settings.
7. Launch the game.

Do not move the DLL or other package files manually.
The manager installs and verifies the Historical Random Start runtime.

Historical Random Start is distributed under the license included in LICENSE.md.